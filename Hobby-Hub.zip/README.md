# 🚀 Hobby Hub

[![MERN Stack](https://img.shields.io/badge/Stack-MERN-blue.svg)](https://mongodb.com)
[![Socket.io](https://img.shields.io/badge/Socket.IO-Real--Time-orange.svg)](https://socket.io)
[![Leaflet](https://img.shields.io/badge/Maps-Leaflet%20%2B%20OSM-green.svg)](https://leafletjs.com)

> **Hobby Hub is a MERN-based social networking platform that connects people through shared hobbies by providing communities, posts, nearby events, and real-time chat in one place.**

---

## 📌 Project Overview

**Hobby Hub** is a full-stack MERN web application designed to help people discover and connect with others who share similar hobbies. Instead of being a generic social media platform, it focuses on building active, meaningful communities around specific interests such as chess, crochet, photography, cycling, painting, and more.

Users can create an account, select their hobbies, join or create hobby-based communities, share posts, comment on discussions, and participate in events or meetups. The platform also uses the user's location to recommend nearby hobby enthusiasts and local events. Additionally, it provides real-time chat so community members can communicate easily.

The ultimate goal of Hobby Hub is to make it easier for people to find like-minded individuals, build vibrant local and online communities, and encourage both online interaction and real-world meetups around shared interests.

---

## 🌟 Key Features

* **User Authentication & Profiles:** Secure registration/login and personalized profiles showing interests and active communities.
* **Hobby Selection & Personalized Onboarding:** Tailored setup to guide users into communities matching their specific hobbies.
* **Community Creation & Management:** Users can create new hobby groups or manage existing ones.
* **Interactive Feed:** Share posts, comment on discussions, and like updates within specific communities.
* **Nearby Hobby Events & Meetups:** Discover local activities, workshops, or informal get-togethers.
* **Real-time Chat:** Seamless communication via one-to-one messaging and group/community chat rooms.
* **Location-Based Recommendations:** Smart discovery of nearby hobby enthusiasts and relevant local events using geographical data.
* **Responsive & Modern UI:** A fully responsive design optimized for mobile, tablet, and desktop viewing.

---

## 🛠️ Tech Stack

### Frontend
* **React.js:** Single Page Application (SPA) framework for dynamic views.
* **Leaflet + OpenStreetMap:** Interactive mapping for displaying nearby events and users.

### Backend
* **Node.js + Express.js:** Scalable and robust server-side architecture.
* **Socket.IO:** Real-time, bi-directional event-based communication.

### Database & Storage
* **MongoDB:** Document-oriented NoSQL database.
* **Cloudinary:** Cloud-based image storage and media optimization.

### Security
* **JSON Web Token (JWT):** Secure token-based authentication.

---

## 📂 Project Structure

```text
Hobby-Hub/
├── backend/            # Express.js Server
│   ├── config/         # Database and third-party API configurations
│   ├── controllers/    # API request handlers
│   ├── middleware/     # Authentication & request processing middleware
│   ├── models/         # MongoDB schemas
│   ├── routes/         # Express API endpoints
│   ├── utils/          # Helper functions & utilities
│   ├── server.js       # Main server entrypoint
│   └── package.json    # Backend dependencies
└── README.md           # Project documentation
```

---

## ⚙️ Getting Started

### Prerequisites
* [Node.js](https://nodejs.org/) (v16+ recommended)
* [MongoDB](https://www.mongodb.com/) (Local instance or Atlas connection URI)
* [Cloudinary Account](https://cloudinary.com/) (For image/media handling)

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/gupta-ishika/Hobby-Hub.git
   cd Hobby-Hub
   ```

2. **Backend Setup:**
   Navigate to the `backend` folder and install dependencies:
   ```bash
   cd backend
   npm install
   ```

3. **Configure Environment Variables:**
   Create a `.env` file in the `backend/` directory and populate it with your configuration credentials:
   ```env
   PORT=5000
   MONGO_URI=your_mongodb_connection_string
   JWT_SECRET=your_jwt_secret_key
   CLOUDINARY_CLOUD_NAME=your_cloudinary_cloud_name
   CLOUDINARY_API_KEY=your_cloudinary_api_key
   CLOUDINARY_API_SECRET=your_cloudinary_api_secret
   ```

4. **Run the Backend Server:**
   ```bash
   # From the backend directory
   npm start
   ```
   The backend server should now be running on the configured port (default `5000`).

---

## 🤝 Contributing

This is a private repository. Only authorized collaborators can contribute. 

To contribute to this project, please follow these steps:

1. Create a new feature/bugfix branch from `main`:
   ```bash
   git checkout -b feature/your-feature-name
   ```
2. Commit your changes:
   ```bash
   git commit -m "Add descriptive commit message"
   ```
3. Push your branch to the origin repository:
   ```bash
   git push origin feature/your-feature-name
   ```
4. Open a Pull Request on GitHub to merge into `main` for code review.

---

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.
