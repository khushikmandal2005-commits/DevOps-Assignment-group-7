const mongoose = require("mongoose");

mongoose.connect(
  "mongodb+srv://gishika701_db_user:if3ZMSm9dPWGHrv0@cluster0.esbvc7t.mongodb.net/hobbyhub?retryWrites=true&w=majority"
)
.then(() => {
  console.log("Connected");
  process.exit();
})
.catch(err => {
  console.error(err);
});