const dns = require("dns").promises;

async function run() {
  try {
    const records = await dns.resolveSrv(
      "_mongodb._tcp.cluster0.q5okkdh.mongodb.net"
    );

    console.log(records);
  } catch (err) {
    console.error(err);
  }
}

run();