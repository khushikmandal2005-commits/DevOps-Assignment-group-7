import dotenv from "dotenv";
import connectDB from "./index.js";
import Hobby from "../models/hobby.model.js";

dotenv.config();

const hobbies = [
    {
        name: "Photography",
        normalizedName: "photography",
        icon: "camera",
        description: "Capturing and creating photographs.",
    },
    {
        name: "Cooking",
        normalizedName: "cooking",
        icon: "utensils",
        description: "Exploring recipes, cooking techniques, and food.",
    },
    {
        name: "Chess",
        normalizedName: "chess",
        icon: "chess",
        description: "Playing and learning the game of chess.",
    },
    {
        name: "Gaming",
        normalizedName: "gaming",
        icon: "gamepad",
        description: "Video games, gaming communities, and discussions.",
    },
    {
        name: "Music",
        normalizedName: "music",
        icon: "music",
        description: "Listening to, creating, and exploring music.",
    },
    {
        name: "Reading",
        normalizedName: "reading",
        icon: "book",
        description: "Books, authors, genres, and reading discussions.",
    },
    {
        name: "Cycling",
        normalizedName: "cycling",
        icon: "bike",
        description: "Cycling, routes, equipment, and experiences.",
    },
    {
        name: "Drawing",
        normalizedName: "drawing",
        icon: "pencil",
        description: "Drawing, sketching, and illustration.",
    },
    {
        name: "Painting",
        normalizedName: "painting",
        icon: "palette",
        description: "Painting techniques, artwork, and creative ideas.",
    },
    {
        name: "Gardening",
        normalizedName: "gardening",
        icon: "leaf",
        description: "Growing plants, gardening techniques, and experiences.",
    },
    {
        name: "Travel",
        normalizedName: "travel",
        icon: "plane",
        description: "Travel experiences, destinations, and tips.",
    },
    {
        name: "Anime",
        normalizedName: "anime",
        icon: "tv",
        description: "Anime, manga, characters, and discussions.",
    },
    {
        name: "Coding",
        normalizedName: "coding",
        icon: "code",
        description: "Programming, software development, and technology.",
    },
    {
        name: "Fitness",
        normalizedName: "fitness",
        icon: "dumbbell",
        description: "Exercise, workouts, and fitness discussions.",
    },
];

const seedHobbies = async () => {
    try {
        await connectDB();

        await Hobby.deleteMany();

        await Hobby.insertMany(hobbies);

        console.log("✅ Hobbies seeded successfully");

        process.exit(0);
    } catch (error) {
        console.error("❌ Hobby seeding failed:", error.message);
        process.exit(1);
    }
};

seedHobbies();