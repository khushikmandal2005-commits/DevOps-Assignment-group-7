// Signup Controller
const signup = (req, res) => {
    res.status(201).json({
        success: true,
        message: "Signup API Working"
    });
};

// Login Controller
const login = (req, res) => {
    res.status(200).json({
        success: true,
        message: "Login API Working"
    });
};

// Get Current User
const getMe = (req, res) => {
    res.status(200).json({
        success: true,
        message: "Current User API Working"
    });
};

module.exports = {
    signup,
    login,
    getMe
};