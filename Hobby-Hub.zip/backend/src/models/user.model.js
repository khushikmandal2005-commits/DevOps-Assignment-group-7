import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true,
        },

        username: {
            type: String,
            required: true,
            unique: true,
            trim: true,
            minlength: 3,
            maxlength: 20,
            match: /^(?![._-])[a-z0-9._-]+(?<![._-])$/,
        },

        email: {
            type: String,
            required: true,
            unique: true,
            trim: true,
            lowercase: true,
        },

        password: {
            type: String,
            required: true,
        },

        bio: {
            type: String,
            trim: true,
            maxlength: 200,
            default: "",
        },

        avatar: {
            type: String,
            default: null,
        },

        hobbies: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Hobby",
            },
        ],
    },
    {
        timestamps: true,
    }
);

const User = mongoose.model("User", userSchema);

export default User;