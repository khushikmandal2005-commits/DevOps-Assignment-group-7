import mongoose from "mongoose";

const communityMemberSchema = new mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },

        role: {
            type: String,
            enum: ["admin", "member"],
            default: "member",
        },

        joinedAt: {
            type: Date,
            default: Date.now,
        },
    },
    {
        _id: false,
    }
);

const communitySchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            unique: true,
            trim: true,
            minlength: 3,
            maxlength: 50,
        },

        description: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: "",
        },

        coverImage: {
            type: String,
            default: null,
        },

        owner: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },

        hobby: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Hobby",
            required: true,
        },

        members: {
            type: [communityMemberSchema],
            default: [],
        },
    },
    {
        timestamps: true,
    }
);
communitySchema.index({ hobby: 1 });
communitySchema.index({ "members.user": 1 });

const Community = mongoose.model("Community", communitySchema);

export default Community;