import mongoose from "mongoose";

const eventParticipantSchema = new mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },

        joinedAt: {
            type: Date,
            default: Date.now,
        },
    },
    {
        _id: false,
    }
);

const eventSchema = new mongoose.Schema(
    {
        title: {
            type: String,
            required: true,
            trim: true,
            minlength: 3,
            maxlength: 100,
        },

        description: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: "",
        },

        date: {
            type: Date,
            required: true,
        },

        location: {
            type: String,
            trim: true,
            maxlength: 200,
            default: "",
        },

        community: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Community",
            required: true,
        },

        createdBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },

        participants: {
            type: [eventParticipantSchema],
            default: [],
        },
    },
    {
        timestamps: true,
    }
);

eventSchema.index({
    community: 1,
    date: 1,
});

const Event = mongoose.model("Event", eventSchema);

export default Event;