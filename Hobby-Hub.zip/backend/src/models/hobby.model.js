import mongoose from "mongoose";

const hobbySchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true,
            minlength: 2,
            maxlength: 40,
        },

        normalizedName: {
            type: String,
            required: true,
            unique: true,
            trim: true,
        },

        icon: {
            type: String,
            default: null,
        },

        description: {
            type: String,
            trim: true,
            maxlength: 500,
            default: "",
        },
    },
    {
        timestamps: true,
    }
);

const Hobby = mongoose.model("Hobby", hobbySchema);

export default Hobby;