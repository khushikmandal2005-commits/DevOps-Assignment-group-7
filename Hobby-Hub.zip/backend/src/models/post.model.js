import mongoose from "mongoose";

const postSchema = new mongoose.Schema(
    {
        author: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },

        community: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Community",
            required: true,
        },

        content: {
            type: String,
            trim: true,
            maxlength: 2000,
            default: "",
        },

        images: {
            type: [String],
            default: [],
            validate: {
                validator: (images) => images.length <= 5,
                message: "A post can have a maximum of 5 images.",
            },
        },

        likes: {
            type: [
                {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: "User",
                },
            ],
            default: [],
        },
    },
    {
        timestamps: true,
    }
);

postSchema.index({
    community: 1,
    createdAt: -1,
});

const Post = mongoose.model("Post", postSchema);

export default Post;