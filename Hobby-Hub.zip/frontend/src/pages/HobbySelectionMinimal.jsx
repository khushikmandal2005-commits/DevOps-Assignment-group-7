export default function HobbySelectionMinimal() {
  return <div className="p-8 text-2xl font-bold font-headline">Hobby Selection (Placeholder)</div>;
}
