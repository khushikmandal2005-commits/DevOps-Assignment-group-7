const { GoogleGenerativeAI } = require('@google/generative-ai');

// Standard Indian & Cafeteria Food Knowledge Base for Fallback Engine
const FOOD_DATABASE = {
  roti: { name: 'Wheat Roti / Chapati', cal: 80, protein: 3, carbs: 15, fats: 1, fiber: 2 },
  chapati: { name: 'Wheat Roti / Chapati', cal: 80, protein: 3, carbs: 15, fats: 1, fiber: 2 },
  fulka: { name: 'Fulka', cal: 70, protein: 2.5, carbs: 14, fats: 0.5, fiber: 2 },
  naan: { name: 'Butter Naan', cal: 260, protein: 6, carbs: 42, fats: 8, fiber: 1.5 },
  paratha: { name: 'Aloo Paratha', cal: 240, protein: 5, carbs: 36, fats: 9, fiber: 3 },
  rice: { name: 'Steamed Basmati Rice', cal: 180, protein: 4, carbs: 40, fats: 0.5, fiber: 1 },
  pulao: { name: 'Veg Pulao', cal: 220, protein: 4.5, carbs: 42, fats: 5, fiber: 2 },
  biryani: { name: 'Veg Biryani', cal: 320, protein: 7, carbs: 52, fats: 10, fiber: 3 },
  chole: { name: 'Chole Masala', cal: 240, protein: 9, carbs: 32, fats: 8, fiber: 7 },
  bhature: { name: 'Bhatura (1 pc)', cal: 290, protein: 5, carbs: 38, fats: 14, fiber: 1 },
  dal: { name: 'Dal Tadka', cal: 160, protein: 8, carbs: 22, fats: 5, fiber: 5 },
  'dal makhani': { name: 'Dal Makhani', cal: 250, protein: 9, carbs: 26, fats: 12, fiber: 6 },
  rajma: { name: 'Rajma Curry', cal: 210, protein: 9, carbs: 30, fats: 6, fiber: 7 },
  paneer: { name: 'Paneer Butter Masala', cal: 310, protein: 12, carbs: 12, fats: 24, fiber: 2 },
  'kadai paneer': { name: 'Kadai Paneer', cal: 270, protein: 13, carbs: 10, fats: 20, fiber: 2.5 },
  idli: { name: 'Steamed Idli (1 pc)', cal: 60, protein: 2, carbs: 12, fats: 0.3, fiber: 1 },
  dosa: { name: 'Plain Dosa', cal: 170, protein: 4, carbs: 29, fats: 4.5, fiber: 1.5 },
  'masala dosa': { name: 'Masala Dosa', cal: 310, protein: 6, carbs: 48, fats: 11, fiber: 3.5 },
  sambar: { name: 'Vegetable Sambar', cal: 90, protein: 3.5, carbs: 14, fats: 2, fiber: 3 },
  chutney: { name: 'Coconut Chutney', cal: 70, protein: 1, carbs: 3, fats: 6, fiber: 1.5 },
  poori: { name: 'Poori (1 pc)', cal: 110, protein: 2, carbs: 14, fats: 6, fiber: 1 },
  bhaji: { name: 'Aloo Bhaji', cal: 150, protein: 3, carbs: 22, fats: 6, fiber: 3 },
  curd: { name: 'Fresh Dahi / Curd', cal: 80, protein: 4, carbs: 5, fats: 4, fiber: 0 },
  dahi: { name: 'Fresh Dahi / Curd', cal: 80, protein: 4, carbs: 5, fats: 4, fiber: 0 },
  lassi: { name: 'Sweet Lassi', cal: 180, protein: 5, carbs: 26, fats: 6, fiber: 0 },
  buttermilk: { name: 'Masala Chaas', cal: 45, protein: 2, carbs: 4, fats: 2, fiber: 0 },
  salad: { name: 'Green Salad', cal: 35, protein: 1.5, carbs: 7, fats: 0.2, fiber: 2.5 },
  gulabjamun: { name: 'Gulab Jamun (1 pc)', cal: 140, protein: 2, carbs: 24, fats: 5, fiber: 0.2 },
  rasgulla: { name: 'Rasgulla (1 pc)', cal: 120, protein: 2.5, carbs: 23, fats: 1.5, fiber: 0 },
  samosa: { name: 'Aloo Samosa (1 pc)', cal: 260, protein: 4, carbs: 32, fats: 13, fiber: 2.5 },
  egg: { name: 'Boiled Egg (1 pc)', cal: 75, protein: 6.5, carbs: 0.6, fats: 5, fiber: 0 },
  'egg curry': { name: 'Egg Curry (2 eggs)', cal: 240, protein: 14, carbs: 8, fats: 16, fiber: 1.5 },
  chicken: { name: 'Chicken Curry', cal: 280, protein: 26, carbs: 6, fats: 17, fiber: 1 }
};

// Compute Mess Health Rating (0-100 scale)
function calculateMessRating(protein, carbs, fats, fiber, calories) {
  let score = 70; // baseline

  // Protein check (Target: 15g-35g per meal)
  if (protein >= 20) score += 12;
  else if (protein >= 12) score += 6;
  else score -= 10;

  // Carbs to Protein Ratio
  const carbProteinRatio = carbs / (protein || 1);
  if (carbProteinRatio > 6) score -= 12;
  else if (carbProteinRatio >= 2.5 && carbProteinRatio <= 4.5) score += 8;

  // Fiber Check
  if (fiber >= 6) score += 10;
  else if (fiber < 3) score -= 8;

  // Fats & Calorie density check
  if (fats > 25) score -= 10;
  if (calories > 800) score -= 8;
  else if (calories >= 400 && calories <= 650) score += 5;

  return Math.min(98, Math.max(35, Math.round(score)));
}

// Generate intelligent AI health tips
function generateHealthVerdict(rating, protein, carbs, fats, fiber, items) {
  let verdict = '';
  const tips = [];

  if (rating >= 75) {
    verdict = 'Excellent balanced meal! High in nutrition with a great protein-to-carbohydrate balance.';
    tips.push('Maintain hydration by taking water 30 mins after your meal.');
    tips.push('Great macro ratio for staying active during lectures!');
  } else if (rating >= 60) {
    verdict = 'Decent mess meal, but slightly carb-heavy. Adding protein or salad would make it ideal.';
    tips.push('Ask for an extra katori of Dal or Dahi for better muscle recovery.');
    tips.push('Grab a raw cucumber/carrot from the salad counter to increase dietary fiber.');
  } else {
    verdict = 'High calorie / carb dense meal with limited protein. Consume in moderation.';
    tips.push('Try swapping extra rice/bhatura for an extra chapati or bowl of sprouts.');
    tips.push('Avoid sugary drinks or heavy sweets immediately after this meal.');
  }

  if (fiber < 4) {
    tips.push('Include raw salad or fruit to aid digestion.');
  }

  return { verdict, tips };
}

// Fallback NLP food parser
function fallbackAnalyzeText(textPrompt) {
  const query = (textPrompt || '').toLowerCase();
  let foundItems = [];
  let totalCal = 0;
  let totalProt = 0;
  let totalCarbs = 0;
  let totalFats = 0;
  let totalFiber = 0;

  const keys = Object.keys(FOOD_DATABASE).sort((a, b) => b.length - a.length);

  keys.forEach(key => {
    if (query.includes(key)) {
      let multiplier = 1;
      const regex = new RegExp(`(\\d+)\\s*${key}|${key}\\s*x?\\s*(\\d+)`, 'i');
      const match = query.match(regex);
      if (match) {
        multiplier = parseInt(match[1] || match[2] || '1', 10);
      }

      const dbItem = FOOD_DATABASE[key];
      const itemCal = Math.round(dbItem.cal * multiplier);
      const itemProt = Math.round(dbItem.protein * multiplier * 10) / 10;
      const itemCarbs = Math.round(dbItem.carbs * multiplier * 10) / 10;
      const itemFats = Math.round(dbItem.fats * multiplier * 10) / 10;
      const itemFiber = Math.round(dbItem.fiber * multiplier * 10) / 10;

      foundItems.push({
        name: `${multiplier > 1 ? multiplier + 'x ' : ''}${dbItem.name}`,
        calories: itemCal,
        protein: itemProt,
        carbs: itemCarbs,
        fats: itemFats
      });

      totalCal += itemCal;
      totalProt += itemProt;
      totalCarbs += itemCarbs;
      totalFats += itemFats;
      totalFiber += itemFiber;
    }
  });

  if (foundItems.length === 0) {
    foundItems = [
      { name: textPrompt || 'Custom Mess Combo', calories: 450, protein: 14, carbs: 65, fats: 12 }
    ];
    totalCal = 450;
    totalProt = 14;
    totalCarbs = 65;
    totalFats = 12;
    totalFiber = 5;
  }

  const rating = calculateMessRating(totalProt, totalCarbs, totalFats, totalFiber, totalCal);
  const { verdict, tips } = generateHealthVerdict(rating, totalProt, totalCarbs, totalFats, totalFiber, foundItems);

  return {
    mealName: textPrompt || 'Scanned Mess Meal',
    foodItems: foundItems.map(i => i.name),
    itemBreakdown: foundItems,
    calories: Math.round(totalCal),
    protein: Math.round(totalProt),
    carbs: Math.round(totalCarbs),
    fats: Math.round(totalFats),
    fiber: Math.round(totalFiber),
    messRating: rating,
    healthVerdict: verdict,
    tips: tips
  };
}

// Main AI Service Exports
async function analyzeText(textPrompt) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.log('[AI Service] GEMINI_API_KEY not set. Using Fallback Engine.');
    return fallbackAnalyzeText(textPrompt);
  }

  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
    const prompt = `You are MessBites AI, an expert nutritionist evaluating college mess / cafeteria food.
Analyze the following food item or meal description: "${textPrompt}".
Provide output strictly in VALID JSON format with NO markdown formatting:
{
  "mealName": "Clean descriptive title of meal",
  "foodItems": ["Item 1 with quantity", "Item 2"],
  "calories": integer,
  "protein": integer_grams,
  "carbs": integer_grams,
  "fats": integer_grams,
  "fiber": integer_grams,
  "messRating": integer_score_0_to_100,
  "healthVerdict": "1-2 sentence nutritional evaluation for a college student",
  "tips": ["Tip 1", "Tip 2", "Tip 3"]
}`;

    const response = await model.generateContent(prompt);
    const text = response.response.text();
    const cleanJson = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    const result = JSON.parse(cleanJson);

    return {
      mealName: result.mealName || textPrompt,
      foodItems: result.foodItems || [textPrompt],
      calories: Number(result.calories) || 500,
      protein: Number(result.protein) || 15,
      carbs: Number(result.carbs) || 70,
      fats: Number(result.fats) || 12,
      fiber: Number(result.fiber) || 5,
      messRating: Number(result.messRating) || 68,
      healthVerdict: result.healthVerdict || 'Decent meal balance for mess food.',
      tips: result.tips || ['Drink water 30 mins after meal', 'Add fresh salad']
    };
  } catch (err) {
    console.error('[AI Service Error]:', err.message);
    return fallbackAnalyzeText(textPrompt);
  }
}

async function analyzeImage(base64Image, mimeType = 'image/jpeg') {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.log('[AI Vision] GEMINI_API_KEY not set. Using Fallback Vision Engine.');
    return fallbackAnalyzeText('Chole Masala + 2 Wheat Roti + Steamed Rice + Salad');
  }

  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
    const imagePart = {
      inlineData: {
        data: base64Image.replace(/^data:image\/\w+;base64,/, ''),
        mimeType: mimeType
      }
    };

    const prompt = `You are MessBites AI. Inspect this cafeteria/mess menu board or food plate image.
Identify all dishes, estimate portion sizes, and calculate full nutritional values.
Output strictly in VALID JSON format with NO markdown:
{
  "mealName": "Identified Meal Title",
  "foodItems": ["Item 1", "Item 2"],
  "calories": integer,
  "protein": integer_grams,
  "carbs": integer_grams,
  "fats": integer_grams,
  "fiber": integer_grams,
  "messRating": integer_score_0_to_100,
  "healthVerdict": "Nutritional evaluation for students",
  "tips": ["Tip 1", "Tip 2", "Tip 3"]
}`;

    const response = await model.generateContent([prompt, imagePart]);
    const text = response.response.text();
    const cleanJson = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    const result = JSON.parse(cleanJson);

    return {
      mealName: result.mealName || 'Scanned Mess Menu',
      foodItems: result.foodItems || ['Scanned Items'],
      calories: Number(result.calories) || 550,
      protein: Number(result.protein) || 18,
      carbs: Number(result.carbs) || 75,
      fats: Number(result.fats) || 14,
      fiber: Number(result.fiber) || 6,
      messRating: Number(result.messRating) || 72,
      healthVerdict: result.healthVerdict || 'Scanned menu analyzed successfully.',
      tips: result.tips || ['Add green salad for extra fiber', 'Balance carbs with protein']
    };
  } catch (err) {
    console.error('[AI Vision Error]:', err.message);
    return fallbackAnalyzeText('Chole Masala + 2 Wheat Roti + Steamed Rice + Salad');
  }
}

module.exports = {
  analyzeText,
  analyzeImage
};
