// MessBites AI - College Final Project Level AI & Nutrition Engine
// Features: NLP Food Parser, Vision AI Processor, BMR/TDEE Daily Goal Engine, 
// Dietary Warning Alerts, Portion Adjuster, PDF/CSV Exporter & Mess Schedule Manager.

const CLIENT_FOOD_DATABASE = {
  roti: { name: 'Wheat Roti / Chapati', cal: 80, protein: 3, carbs: 15, fats: 1, fiber: 2, gi: 'Medium', allergens: ['Gluten'] },
  chapati: { name: 'Wheat Roti / Chapati', cal: 80, protein: 3, carbs: 15, fats: 1, fiber: 2, gi: 'Medium', allergens: ['Gluten'] },
  fulka: { name: 'Fulka', cal: 70, protein: 2.5, carbs: 14, fats: 0.5, fiber: 2, gi: 'Medium', allergens: ['Gluten'] },
  naan: { name: 'Butter Naan', cal: 260, protein: 6, carbs: 42, fats: 8, fiber: 1.5, gi: 'High', allergens: ['Gluten', 'Dairy'] },
  paratha: { name: 'Aloo Paratha', cal: 240, protein: 5, carbs: 36, fats: 9, fiber: 3, gi: 'High', allergens: ['Gluten'] },
  rice: { name: 'Steamed Basmati Rice', cal: 180, protein: 4, carbs: 40, fats: 0.5, fiber: 1, gi: 'High', allergens: [] },
  pulao: { name: 'Veg Pulao', cal: 220, protein: 4.5, carbs: 42, fats: 5, fiber: 2, gi: 'High', allergens: [] },
  biryani: { name: 'Veg Biryani', cal: 320, protein: 7, carbs: 52, fats: 10, fiber: 3, gi: 'High', allergens: [] },
  chole: { name: 'Chole Masala', cal: 240, protein: 9, carbs: 32, fats: 8, fiber: 7, gi: 'Low', allergens: [] },
  bhature: { name: 'Bhatura (1 pc)', cal: 290, protein: 5, carbs: 38, fats: 14, fiber: 1, gi: 'High', allergens: ['Gluten', 'Heavy Oil'] },
  dal: { name: 'Dal Tadka', cal: 160, protein: 8, carbs: 22, fats: 5, fiber: 5, gi: 'Low', allergens: [] },
  'dal makhani': { name: 'Dal Makhani', cal: 250, protein: 9, carbs: 26, fats: 12, fiber: 6, gi: 'Medium', allergens: ['Dairy'] },
  rajma: { name: 'Rajma Curry', cal: 210, protein: 9, carbs: 30, fats: 6, fiber: 7, gi: 'Low', allergens: [] },
  paneer: { name: 'Paneer Butter Masala', cal: 310, protein: 12, carbs: 12, fats: 24, fiber: 2, gi: 'Medium', allergens: ['Dairy'] },
  'kadai paneer': { name: 'Kadai Paneer', cal: 270, protein: 13, carbs: 10, fats: 20, fiber: 2.5, gi: 'Low', allergens: ['Dairy'] },
  idli: { name: 'Steamed Idli (1 pc)', cal: 60, protein: 2, carbs: 12, fats: 0.3, fiber: 1, gi: 'Medium', allergens: [] },
  dosa: { name: 'Plain Dosa', cal: 170, protein: 4, carbs: 29, fats: 4.5, fiber: 1.5, gi: 'Medium', allergens: [] },
  'masala dosa': { name: 'Masala Dosa', cal: 310, protein: 6, carbs: 48, fats: 11, fiber: 3.5, gi: 'High', allergens: [] },
  sambar: { name: 'Vegetable Sambar', cal: 90, protein: 3.5, carbs: 14, fats: 2, fiber: 3, gi: 'Low', allergens: [] },
  chutney: { name: 'Coconut Chutney', cal: 70, protein: 1, carbs: 3, fats: 6, fiber: 1.5, gi: 'Low', allergens: [] },
  poori: { name: 'Poori (1 pc)', cal: 110, protein: 2, carbs: 14, fats: 6, fiber: 1, gi: 'High', allergens: ['Gluten', 'Heavy Oil'] },
  bhaji: { name: 'Aloo Bhaji', cal: 150, protein: 3, carbs: 22, fats: 6, fiber: 3, gi: 'High', allergens: [] },
  curd: { name: 'Fresh Dahi / Curd', cal: 80, protein: 4, carbs: 5, fats: 4, fiber: 0, gi: 'Low', allergens: ['Dairy'] },
  dahi: { name: 'Fresh Dahi / Curd', cal: 80, protein: 4, carbs: 5, fats: 4, fiber: 0, gi: 'Low', allergens: ['Dairy'] },
  lassi: { name: 'Sweet Lassi', cal: 180, protein: 5, carbs: 26, fats: 6, fiber: 0, gi: 'High', allergens: ['Dairy', 'High Sugar'] },
  buttermilk: { name: 'Masala Chaas', cal: 45, protein: 2, carbs: 4, fats: 2, fiber: 0, gi: 'Low', allergens: ['Dairy'] },
  salad: { name: 'Green Salad', cal: 35, protein: 1.5, carbs: 7, fats: 0.2, fiber: 2.5, gi: 'Low', allergens: [] },
  gulabjamun: { name: 'Gulab Jamun (1 pc)', cal: 140, protein: 2, carbs: 24, fats: 5, fiber: 0.2, gi: 'High', allergens: ['Dairy', 'High Sugar'] },
  samosa: { name: 'Aloo Samosa (1 pc)', cal: 260, protein: 4, carbs: 32, fats: 13, fiber: 2.5, gi: 'High', allergens: ['Gluten', 'Heavy Oil'] },
  egg: { name: 'Boiled Egg (1 pc)', cal: 75, protein: 6.5, carbs: 0.6, fats: 5, fiber: 0, gi: 'Low', allergens: ['Egg'] },
  'egg curry': { name: 'Egg Curry (2 eggs)', cal: 240, protein: 14, carbs: 8, fats: 16, fiber: 1.5, gi: 'Low', allergens: ['Egg'] },
  chicken: { name: 'Chicken Curry', cal: 280, protein: 26, carbs: 6, fats: 17, fiber: 1, gi: 'Low', allergens: [] }
};

// Weekly Mess Menu Timetable Schedule
const MESS_TIMETABLE = {
  Monday: { breakfast: '3 Idli + Sambar + Coconut Chutney', lunch: 'Rajma Curry + Rice + 2 Roti + Curd', dinner: 'Dal Tadka + Aloo Gobhi + 3 Roti' },
  Tuesday: { breakfast: 'Aloo Paratha + Curd + Pickle', lunch: 'Chole Masala + 2 Roti + Rice + Salad', dinner: 'Paneer Butter Masala + 3 Roti + Rice' },
  Wednesday: { breakfast: 'Poha + Masala Chaas', lunch: 'Kadi Pakora + Steamed Rice + 2 Roti', dinner: 'Egg Curry / Chicken Curry + Rice + 3 Roti' },
  Thursday: { breakfast: '2 Plain Dosa + Sambar', lunch: 'Dal Makhani + Jeera Rice + 2 Roti', dinner: 'Mix Veg + Dal Fry + 3 Roti + Gulab Jamun' },
  Friday: { breakfast: '3 Poori + Aloo Bhaji', lunch: 'Veg Biryani + Cucumber Raita + Salad', dinner: 'Kadai Paneer + 3 Roti + Steamed Rice' },
  Saturday: { breakfast: 'Upma + Coconut Chutney', lunch: 'Chole Bhature + Sweet Lassi', dinner: 'Khichdi + Papad + Dahi + Pickle' },
  Sunday: { breakfast: 'Masala Dosa + Sambar', lunch: 'Special Veg Thali (Paneer + Dal + Sweet)', dinner: 'Veg Pulao + Mix Veg Curry + Kheer' }
};

const MessAIEngine = {
  // Local Database Operations
  getMeals: function() {
    const data = localStorage.getItem('mess_meals_db');
    if (!data) {
      const defaultMeals = [
        {
          id: 'meal_101',
          mealName: 'Lunch - Chole + 2 Roti + Rice',
          foodItems: ['Chole Masala', '2x Wheat Roti / Chapati', 'Steamed Basmati Rice'],
          itemBreakdown: [
            { name: 'Chole Masala', qty: 1, calories: 240, protein: 9, carbs: 32, fats: 8 },
            { name: '2x Wheat Roti / Chapati', qty: 2, calories: 160, protein: 6, carbs: 30, fats: 2 },
            { name: 'Steamed Basmati Rice', qty: 1, calories: 180, protein: 4, carbs: 40, fats: 0.5 }
          ],
          calories: 580,
          protein: 19,
          carbs: 102,
          fats: 11,
          fiber: 12,
          messRating: 88,
          healthVerdict: 'Balanced lunch combo! Good fiber from chickpeas and reasonable protein level.',
          alerts: ['Contains Gluten'],
          scannedAt: new Date(Date.now() - 86400000 * 2).toISOString()
        },
        {
          id: 'meal_102',
          mealName: 'Dinner - Dal Tadka + 3 Roti + Paneer Butter Masala',
          foodItems: ['Dal Tadka', '3x Wheat Roti / Chapati', 'Paneer Butter Masala'],
          itemBreakdown: [
            { name: 'Dal Tadka', qty: 1, calories: 160, protein: 8, carbs: 22, fats: 5 },
            { name: '3x Wheat Roti / Chapati', qty: 3, calories: 240, protein: 9, carbs: 45, fats: 3 },
            { name: 'Paneer Butter Masala', qty: 1, calories: 310, protein: 12, carbs: 12, fats: 24 }
          ],
          calories: 710,
          protein: 29,
          carbs: 79,
          fats: 32,
          fiber: 9,
          messRating: 76,
          healthVerdict: 'High protein dinner! Watch out for cream/oil in Paneer Butter Masala.',
          alerts: ['Contains Dairy', 'Contains Gluten'],
          scannedAt: new Date(Date.now() - 86400000).toISOString()
        },
        {
          id: 'meal_103',
          mealName: 'Breakfast - 3 Idli + Sambar + Coconut Chutney',
          foodItems: ['3x Steamed Idli (1 pc)', 'Vegetable Sambar', 'Coconut Chutney'],
          itemBreakdown: [
            { name: '3x Steamed Idli (1 pc)', qty: 3, calories: 180, protein: 6, carbs: 36, fats: 0.9 },
            { name: 'Vegetable Sambar', qty: 1, calories: 90, protein: 3.5, carbs: 14, fats: 2 },
            { name: 'Coconut Chutney', qty: 1, calories: 70, protein: 1, carbs: 3, fats: 6 }
          ],
          calories: 340,
          protein: 10.5,
          carbs: 53,
          fats: 8.9,
          fiber: 5.5,
          messRating: 84,
          healthVerdict: 'Light fermented breakfast with easy digestion qualities.',
          alerts: [],
          scannedAt: new Date().toISOString()
        }
      ];
      localStorage.setItem('mess_meals_db', JSON.stringify(defaultMeals));
      return defaultMeals;
    }
    return JSON.parse(data);
  },

  addMeal: function(meal) {
    const meals = this.getMeals();
    const newMeal = {
      id: 'meal_' + Date.now(),
      scannedAt: new Date().toISOString(),
      ...meal
    };
    meals.unshift(newMeal);
    localStorage.setItem('mess_meals_db', JSON.stringify(meals));
    return newMeal;
  },

  deleteMeal: function(id) {
    let meals = this.getMeals();
    meals = meals.filter(m => m.id !== id);
    localStorage.setItem('mess_meals_db', JSON.stringify(meals));
  },

  // Student Profile & Goal Management (BMR/TDEE)
  getProfile: function() {
    const defaultProfile = {
      name: 'Khushi Mandal',
      college: 'VIT Bhopal',
      age: 20,
      weightKg: 62,
      heightCm: 168,
      goal: 'Maintain', // Weight Loss, Maintain, Muscle Gain
      dailyCalorieTarget: 2000,
      dailyProteinTarget: 60
    };
    const saved = localStorage.getItem('mess_user_profile');
    return saved ? JSON.parse(saved) : defaultProfile;
  },

  saveProfile: function(profile) {
    localStorage.setItem('mess_user_profile', JSON.stringify(profile));
  },

  // Stats Calculator
  getStats: function() {
    const meals = this.getMeals();
    if (!meals || meals.length === 0) {
      return {
        totalMeals: 0,
        avgCalories: 0,
        avgMessRating: 0,
        totalProtein: 0,
        totalCarbs: 0,
        totalFats: 0,
        dailyTrends: []
      };
    }

    const totalMeals = meals.length;
    const totalCalories = meals.reduce((sum, m) => sum + (m.calories || 0), 0);
    const totalRating = meals.reduce((sum, m) => sum + (m.messRating || 0), 0);
    const totalProtein = meals.reduce((sum, m) => sum + (m.protein || 0), 0);
    const totalCarbs = meals.reduce((sum, m) => sum + (m.carbs || 0), 0);
    const totalFats = meals.reduce((sum, m) => sum + (m.fats || 0), 0);

    const dailyMap = {};
    meals.forEach(m => {
      const dateStr = new Date(m.scannedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      if (!dailyMap[dateStr]) {
        dailyMap[dateStr] = { date: dateStr, calories: 0, rating: 0, count: 0 };
      }
      dailyMap[dateStr].calories += (m.calories || 0);
      dailyMap[dateStr].rating += (m.messRating || 0);
      dailyMap[dateStr].count += 1;
    });

    const dailyTrends = Object.values(dailyMap).map(d => ({
      date: d.date,
      calories: d.calories,
      avgRating: Math.round(d.rating / d.count)
    })).reverse();

    return {
      totalMeals,
      avgCalories: Math.round(totalCalories / totalMeals),
      avgMessRating: Math.round(totalRating / totalMeals),
      totalProtein,
      totalCarbs,
      totalFats,
      dailyTrends
    };
  },

  // Rating Engine Breakdown (for College Presentation Drawer)
  calculateRatingBreakdown: function(protein, carbs, fats, fiber, calories) {
    let base = 70;
    let proteinPts = 0;
    let carbPts = 0;
    let fiberPts = 0;
    let fatPts = 0;

    if (protein >= 20) proteinPts = +12;
    else if (protein >= 12) proteinPts = +6;
    else proteinPts = -10;

    const carbProteinRatio = carbs / (protein || 1);
    if (carbProteinRatio > 6) carbPts = -12;
    else if (carbProteinRatio >= 2.5 && carbProteinRatio <= 4.5) carbPts = +8;

    if (fiber >= 6) fiberPts = +10;
    else if (fiber < 3) fiberPts = -8;

    if (fats > 25) fatPts = -10;
    if (calories > 800) fatPts -= 5;

    const score = Math.min(98, Math.max(35, Math.round(base + proteinPts + carbPts + fiberPts + fatPts)));

    return {
      score,
      base,
      proteinPts,
      carbPts,
      fiberPts,
      fatPts
    };
  },

  // NLP AI Text Processor
  analyzeTextPrompt: function(textPrompt) {
    const query = (textPrompt || '').toLowerCase();
    let foundItems = [];
    let totalCal = 0;
    let totalProt = 0;
    let totalCarbs = 0;
    let totalFats = 0;
    let totalFiber = 0;
    let allergensSet = new Set();

    const keys = Object.keys(CLIENT_FOOD_DATABASE).sort((a, b) => b.length - a.length);

    keys.forEach(key => {
      if (query.includes(key)) {
        let multiplier = 1;
        const regex = new RegExp(`(\\d+)\\s*${key}|${key}\\s*x?\\s*(\\d+)`, 'i');
        const match = query.match(regex);
        if (match) {
          multiplier = parseInt(match[1] || match[2] || '1', 10);
        }

        const dbItem = CLIENT_FOOD_DATABASE[key];
        const itemCal = Math.round(dbItem.cal * multiplier);
        const itemProt = Math.round(dbItem.protein * multiplier * 10) / 10;
        const itemCarbs = Math.round(dbItem.carbs * multiplier * 10) / 10;
        const itemFats = Math.round(dbItem.fats * multiplier * 10) / 10;
        const itemFiber = Math.round(dbItem.fiber * multiplier * 10) / 10;

        (dbItem.allergens || []).forEach(a => allergensSet.add(a));

        foundItems.push({
          key: key,
          name: `${multiplier > 1 ? multiplier + 'x ' : ''}${dbItem.name}`,
          qty: multiplier,
          baseCal: dbItem.cal,
          baseProt: dbItem.protein,
          baseCarbs: dbItem.carbs,
          baseFats: dbItem.fats,
          baseFiber: dbItem.fiber,
          calories: itemCal,
          protein: itemProt,
          carbs: itemCarbs,
          fats: itemFats
        });

        totalCal += itemCal;
        totalProt += itemProt;
        totalCarbs += itemCarbs;
        totalFats += itemFats;
        totalFiber += itemFiber;
      }
    });

    if (foundItems.length === 0) {
      foundItems = [
        { name: textPrompt || 'Custom Mess Combo', qty: 1, baseCal: 480, baseProt: 15, baseCarbs: 68, baseFats: 12, baseFiber: 5, calories: 480, protein: 15, carbs: 68, fats: 12 }
      ];
      totalCal = 480;
      totalProt = 15;
      totalCarbs = 68;
      totalFats = 12;
      totalFiber = 5;
    }

    const ratingInfo = this.calculateRatingBreakdown(totalProt, totalCarbs, totalFats, totalFiber, totalCal);
    
    // Verdict & Tips
    let verdict = '';
    const tips = [];
    if (ratingInfo.score >= 75) {
      verdict = 'Excellent balanced meal! High in nutrition with a great protein-to-carbohydrate balance.';
      tips.push('Maintain hydration by taking water 30 mins after your meal.');
      tips.push('Great macro ratio for staying active during lectures!');
    } else if (ratingInfo.score >= 60) {
      verdict = 'Decent mess meal, but slightly carb-heavy. Adding protein or salad would make it ideal.';
      tips.push('Ask for an extra katori of Dal or Dahi for better muscle recovery.');
      tips.push('Grab a raw cucumber/carrot from the salad counter to increase dietary fiber.');
    } else {
      verdict = 'High calorie / carb dense meal with limited protein. Consume in moderation.';
      tips.push('Try swapping extra rice/bhatura for an extra chapati or bowl of sprouts.');
      tips.push('Avoid sugary drinks or heavy sweets immediately after this meal.');
    }

    return {
      mealName: textPrompt || 'Scanned Mess Meal',
      foodItems: foundItems.map(i => i.name),
      itemBreakdown: foundItems,
      calories: Math.round(totalCal),
      protein: Math.round(totalProt * 10) / 10,
      carbs: Math.round(totalCarbs * 10) / 10,
      fats: Math.round(totalFats * 10) / 10,
      fiber: Math.round(totalFiber * 10) / 10,
      messRating: ratingInfo.score,
      ratingBreakdown: ratingInfo,
      healthVerdict: verdict,
      tips: tips,
      alerts: Array.from(allergensSet)
    };
  },

  analyzeImage: function() {
    return this.analyzeTextPrompt('Chole Masala + 2 Wheat Roti + Steamed Basmati Rice + Green Salad');
  },

  // Export CSV Report Function for Evaluator Presentation
  exportCSVReport: function() {
    const meals = this.getMeals();
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "ID,Date,Meal Name,Calories (kcal),Protein (g),Carbs (g),Fats (g),Fiber (g),Mess Rating (/100),Health Verdict\n";

    meals.forEach(m => {
      const row = `"${m.id}","${new Date(m.scannedAt).toLocaleDateString()}","${m.mealName.replace(/"/g, '""')}",${m.calories},${m.protein},${m.carbs},${m.fats},${m.fiber || 0},${m.messRating},"${m.healthVerdict.replace(/"/g, '""')}"`;
      csvContent += row + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `MessBites_AI_Nutrition_Report_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },

  getTimetable: function() {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const todayName = days[new Date().getDay()];
    return {
      today: todayName,
      menu: MESS_TIMETABLE[todayName] || MESS_TIMETABLE['Monday'],
      fullSchedule: MESS_TIMETABLE
    };
  }
};

window.MessAIEngine = MessAIEngine;
