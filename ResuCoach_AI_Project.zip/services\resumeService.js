// Resume AI Service — Powered by Google Gemini
// Handles: resume analysis, interview question generation, answer evaluation

const { GoogleGenerativeAI } = require('@google/generative-ai');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

// ─── Helper: Get Gemini Model ────────────────────────────────────────────────
function getModel() {
  return genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
}

// ─── Helper: Safe JSON Parse from Gemini ─────────────────────────────────────
function safeParseJSON(text) {
  try {
    const cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    return JSON.parse(cleaned);
  } catch (e) {
    throw new Error('AI response could not be parsed. Please try again.');
  }
}

// ─── 1. Analyze Resume ───────────────────────────────────────────────────────
async function analyzeResume(resumeText, jobRole, experienceLevel = 'Mid-level') {
  if (!process.env.GEMINI_API_KEY) {
    return getMockAnalysis(jobRole, experienceLevel);
  }

  const model = getModel();
  const prompt = `
You are an expert career coach and ATS (Applicant Tracking System) specialist.
Analyze the following resume for a "${jobRole}" position at ${experienceLevel} level.

RESUME TEXT:
---
${resumeText.substring(0, 8000)}
---

Return ONLY a valid JSON object (no markdown, no explanation) with this exact structure:
{
  "overallScore": <number 0-100>,
  "atsScore": <number 0-100>,
  "communicationScore": <number 0-100>,
  "impactScore": <number 0-100>,
  "presentSkills": [<list of skills found in the resume>],
  "missingSkills": [<list of important skills for ${jobRole} missing from resume>],
  "strengths": [<3-4 specific strengths found>],
  "improvements": [<3-4 specific improvement suggestions>],
  "sectionFeedback": {
    "summary": "<feedback on professional summary section, or 'Section not found'>",
    "experience": "<feedback on work experience section>",
    "education": "<feedback on education section>",
    "skills": "<feedback on skills section>"
  },
  "rewordSuggestions": [
    {
      "original": "<original weak phrase from resume>",
      "improved": "<stronger, more impactful version>",
      "reason": "<why this is better>"
    }
  ],
  "keywordsMissing": [<important keywords for ATS that are missing>],
  "overallVerdict": "<2-3 sentence overall assessment>"
}`;

  const result = await model.generateContent(prompt);
  const text = result.response.text();
  return safeParseJSON(text);
}

// ─── 2. Generate Mock Interview Questions ───────────────────────────────────
async function generateInterviewQuestions(resumeText, jobRole, difficulty = 'Medium') {
  if (!process.env.GEMINI_API_KEY) {
    return getMockInterviewQuestions(jobRole);
  }

  const model = getModel();
  const prompt = `
You are an expert technical interviewer for ${jobRole} positions.
Based on the following resume, generate exactly 10 interview questions at ${difficulty} difficulty.
Create a mix of: Technical (3), Behavioral (3), Situational (2), Role-specific (2).

RESUME SNIPPET:
---
${resumeText.substring(0, 4000)}
---

Return ONLY a valid JSON array (no markdown) with this exact structure:
[
  {
    "id": 1,
    "question": "<the interview question>",
    "type": "Technical|Behavioral|Situational|Role-specific",
    "difficulty": "${difficulty}",
    "timeLimit": <seconds: 60-180>,
    "hint": "<a helpful hint for the candidate>",
    "keyPoints": ["<point 1>", "<point 2>", "<point 3>"]
  }
]`;

  const result = await model.generateContent(prompt);
  const text = result.response.text();
  return safeParseJSON(text);
}

// ─── 3. Evaluate Interview Answer ───────────────────────────────────────────
async function evaluateAnswer(question, userAnswer, jobRole) {
  if (!process.env.GEMINI_API_KEY) {
    return getMockEvaluation(userAnswer);
  }

  const model = getModel();
  const prompt = `
You are an expert interview coach evaluating a response for a ${jobRole} position.

QUESTION: "${question}"
CANDIDATE'S ANSWER: "${userAnswer}"

Return ONLY a valid JSON object (no markdown) with this exact structure:
{
  "score": <number 0-10>,
  "grade": "A+|A|B+|B|C|D|F",
  "feedback": "<2-3 sentences of constructive feedback>",
  "keyPointsCovered": ["<point covered>"],
  "missedPoints": ["<important point they missed>"],
  "improvedAnswer": "<a better version of their answer in 3-4 sentences>",
  "encouragement": "<a short motivational message>"
}`;

  const result = await model.generateContent(prompt);
  const text = result.response.text();
  return safeParseJSON(text);
}

// ─── Mock Data Fallbacks (when no API key) ──────────────────────────────────
function getMockAnalysis(jobRole, experienceLevel) {
  return {
    overallScore: 72,
    atsScore: 68,
    communicationScore: 80,
    impactScore: 65,
    presentSkills: ['JavaScript', 'React', 'Node.js', 'Git', 'REST APIs', 'HTML/CSS'],
    missingSkills: ['TypeScript', 'Docker', 'AWS/Cloud', 'System Design', 'GraphQL'],
    strengths: [
      'Strong technical foundation with modern web technologies',
      'Good project experience demonstrated with real-world applications',
      'Clear educational background in relevant field'
    ],
    improvements: [
      'Add quantifiable metrics to experience bullets (e.g., "Improved load time by 40%")',
      'Include a compelling professional summary at the top',
      'Add missing cloud/DevOps skills that are in high demand',
      'Tailor keywords specifically for ' + jobRole + ' roles'
    ],
    sectionFeedback: {
      summary: 'Professional summary is missing or lacks impact. Add a 2-3 sentence pitch highlighting your unique value.',
      experience: 'Experience section is present but bullets are weak. Start each with strong action verbs and add numbers.',
      education: 'Education section looks good. Consider adding relevant coursework or GPA if strong.',
      skills: 'Skills section needs organization — group by category (Languages, Frameworks, Tools).'
    },
    rewordSuggestions: [
      {
        original: 'Worked on website development',
        improved: 'Engineered and deployed 3 full-stack web applications using React and Node.js, reducing page load time by 35%',
        reason: 'Uses action verb, specifies technologies, and includes measurable impact'
      },
      {
        original: 'Helped team with projects',
        improved: 'Collaborated with a 5-member agile team to deliver 2 production features ahead of schedule',
        reason: 'Quantifies team size and demonstrates delivery success'
      },
      {
        original: 'Good knowledge of programming',
        improved: 'Proficient in JavaScript, Python, and Java with 2+ years of hands-on development experience',
        reason: 'Specific languages and experience duration beats vague claims'
      }
    ],
    keywordsMissing: ['Agile', 'CI/CD', 'Microservices', 'API Integration', 'Unit Testing'],
    overallVerdict: `Your resume shows solid ${experienceLevel} potential for ${jobRole} roles, but needs quantifiable achievements and better keyword optimization to pass ATS filters. With targeted improvements, your score could reach 85+.`
  };
}

function getMockInterviewQuestions(jobRole) {
  return [
    { id: 1, question: `Walk me through your most challenging ${jobRole} project and how you overcame obstacles.`, type: 'Behavioral', difficulty: 'Medium', timeLimit: 120, hint: 'Use the STAR method: Situation, Task, Action, Result', keyPoints: ['specific challenge', 'your role', 'actions taken', 'measurable outcome'] },
    { id: 2, question: 'Explain the difference between synchronous and asynchronous programming with a real example.', type: 'Technical', difficulty: 'Medium', timeLimit: 90, hint: 'Think about callbacks, promises, async/await', keyPoints: ['blocking vs non-blocking', 'use case example', 'JavaScript context'] },
    { id: 3, question: 'Tell me about a time you disagreed with a teammate. How did you resolve it?', type: 'Behavioral', difficulty: 'Medium', timeLimit: 120, hint: 'Focus on communication and collaboration skills', keyPoints: ['empathy', 'open communication', 'finding common ground', 'positive outcome'] },
    { id: 4, question: 'How would you design a URL shortener system like bit.ly from scratch?', type: 'Technical', difficulty: 'Hard', timeLimit: 180, hint: 'Think about scale: hashing, database, redirects', keyPoints: ['hash generation', 'database choice', 'scalability', 'caching'] },
    { id: 5, question: 'Where do you see yourself in 3-5 years in your career?', type: 'Situational', difficulty: 'Easy', timeLimit: 60, hint: 'Align with the company growth and your specialization goals', keyPoints: ['career clarity', 'growth mindset', 'alignment with role'] },
    { id: 6, question: 'Explain RESTful API design principles and when you would use GraphQL instead.', type: 'Technical', difficulty: 'Medium', timeLimit: 120, hint: 'Cover HTTP methods, statelessness, and GraphQL use cases', keyPoints: ['REST principles', 'HTTP methods', 'GraphQL advantages', 'trade-offs'] },
    { id: 7, question: 'Describe a situation where you had to learn a new technology quickly under pressure.', type: 'Behavioral', difficulty: 'Medium', timeLimit: 120, hint: 'Show your learning agility and resourcefulness', keyPoints: ['learning approach', 'resources used', 'timeline', 'outcome'] },
    { id: 8, question: 'If you discover a critical bug in production 1 hour before a major product launch, what do you do?', type: 'Situational', difficulty: 'Hard', timeLimit: 150, hint: 'Think about communication, risk assessment, and quick fixes vs rollback', keyPoints: ['immediate escalation', 'risk evaluation', 'hotfix vs rollback', 'documentation'] },
    { id: 9, question: `What makes you the right candidate for this ${jobRole} position specifically?`, type: 'Role-specific', difficulty: 'Medium', timeLimit: 90, hint: 'Connect your specific skills to their job requirements', keyPoints: ['unique skills', 'relevant experience', 'cultural fit', 'enthusiasm'] },
    { id: 10, question: 'How do you stay updated with the latest trends and technologies in your field?', type: 'Role-specific', difficulty: 'Easy', timeLimit: 60, hint: 'Mention specific resources, communities, projects', keyPoints: ['specific resources', 'active learning', 'practical application'] }
  ];
}

function getMockEvaluation(answer) {
  const score = answer && answer.length > 50 ? Math.floor(Math.random() * 3) + 6 : Math.floor(Math.random() * 3) + 3;
  const grades = { 9: 'A+', 8: 'A', 7: 'B+', 6: 'B', 5: 'C', 4: 'D', 3: 'D' };
  return {
    score,
    grade: grades[score] || 'C',
    feedback: score >= 7
      ? 'Great answer! You demonstrated clear understanding and used specific examples effectively.'
      : 'Your answer covers the basics but could be stronger. Add specific examples and quantify your impact.',
    keyPointsCovered: ['Identified the core problem', 'Mentioned relevant experience'],
    missedPoints: score < 8 ? ['Could add measurable results', 'Specific technology details would help'] : [],
    improvedAnswer: 'A stronger answer would start with a specific situation, explain the exact steps you took, and finish with a measurable result that demonstrates impact.',
    encouragement: score >= 7 ? '🌟 Excellent work! You are interview-ready!' : '💪 Keep practicing — you are getting there!'
  };
}

module.exports = { analyzeResume, generateInterviewQuestions, evaluateAnswer };
